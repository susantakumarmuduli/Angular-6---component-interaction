import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ApicallService } from '../apicall.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {
  @Input() public parentData;
  @Output() public childEvent = new EventEmitter();
  public empList = [];
  constructor(private _ApicallService: ApicallService) { }

  ngOnInit() {
    this._ApicallService.getData()
    .subscribe(data => this.empList = data);
  }
  asas() {
  this.childEvent.emit('Hey susanta');
  }
}
