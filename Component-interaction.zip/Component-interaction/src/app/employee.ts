export interface IEmployee {
  name: string;
  email: string;
}
